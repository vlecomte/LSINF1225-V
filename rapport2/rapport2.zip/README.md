# Liste des fichiers

Dans cette archive, on retrouve les fichiers suivants :
- `README.md` : ce fichier, qui décrit les fichiers se trouvant dans l'archive
- `stories.pdf` : notre ensemble représentatif d'user stories
- `crc.pdf` : nos cartes CRC
- `uml.png` : notre schéma conceptuel UML
- `uml-dao.png` : notre schéma conceptuel UML, avec classes DAO
- `sequence.pdf` : nos diagrammes de séquence
- `conception.pdf` : un court rapport décrivant nos choix de conception
