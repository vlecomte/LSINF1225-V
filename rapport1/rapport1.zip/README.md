# Liste des fichiers

Dans cette archive, on retrouve les fichiers suivants :
- `README.md` : ce fichier, qui décrit les fichiers se trouvant dans l'archive
- `faits.pdf` : une liste de faits élémentaires
- `schema-orm.pdf` : le schéma conceptuel ORM complet
- `population.pdf` : des populations représentatives pour les relations les plus importantes
- `schema-relationnel.pdf` : le schéma relationnel correspondant au schéma ORM
- `bartender.sqlite` : une base de donnée contenant les faits élémentaires décrits
- `requetes.sql` : les requêtes SQL de test
- `conception.pdf` : un court rapport décrivant les choix de conception
